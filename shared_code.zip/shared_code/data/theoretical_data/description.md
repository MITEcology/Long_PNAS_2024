`load(uniform_omega_tbl.RData)` is used in `code/fig2BC.R` for **Figure 2**.
It collect and complies all the results from running `code/fig2A.R` . Specifically, it contains the result from `sizes = c(3,12)` and by using uniformly distributed feasible omega values.

`load(glv_omegass_seed200_uniform.RData)` is used in `code/figS2_glv.R` for **Figure S2**.
It contains the result from running the code `omegass <- ensem_geometry(interaction_mats)`


`load(lnorm1_omega_tbl.RData)` can alsed be used in  `code/fig2BC.R` for **Figure S4**.
It collect and complies all the results from running `code/fig2A.R`. Specifically, it contains the result from `sizes = c(3,12)` and by using lognormal distribued (with logmean=1, logsd=1) feasible omega values.


`load(lnorm2_omega_tbl.RData)` can alsed be used in  `code/fig2BC.R` for **Figure S4**.
It collect and complies all the results from running `code/fig2A.R`. Specifically, it contains the result from `sizes = c(3,12)` and by using lognormal distribued (with logmean=-0.837, logsd=0.536) feasible omega values.