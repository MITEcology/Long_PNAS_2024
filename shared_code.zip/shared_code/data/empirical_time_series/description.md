`gut_donor_am.csv` 
source: Poyet, M., M. Groussin, S. M. Gibbons, J. Avila-Pacheco, X. Jiang, S. M. Kearney, A. R. Perrotta, et al. “A Library of Human Gut Bacterial Isolates Paired with Longitudinal Multiomics Data Enables Mechanistic Microbiome Research.” *Nature Medicine* 25, no. 9 (September 2019): 1442–52. https://doi.org/10.1038/s41591-019-0559-3.
from the donor "am"

`ocean_site_37.csv`
source: Martin-Platero, Antonio M., Brian Cleary, Kathryn Kauffman, Sarah P. Preheim, Dennis J. McGillicuddy, Eric J. Alm, and Martin F. Polz. “High Resolution Time Series Reveals Cohesive but Short-Lived Communities in Coastal Plankton.” *Nature Communications* 9, no. 1 (January 18, 2018): 266. https://doi.org/10.1038/s41467-017-02571-4.
from the site ".37"

`oral_subject_a.csv`
source: David, Lawrence A, Arne C Materna, Jonathan Friedman, Maria I Campos-Baptista, Matthew C Blackburn, Allison Perrotta, Susan E Erdman, and Eric J Alm. Host Lifestyle Affects Human Microbiota on Daily Timescales.” Genome Biology 15, no. 7 (2014): R89. https://doi.org/10.1186/gb-2014-15-7-r89.
from the subject "A"

`vaginal_subject_5.csv`
source: Gajer, Pawel, Rebecca M. Brotman, Guoyun Bai, Joyce Sakamoto, Ursel M. E. Schütte, Xue Zhong, Sara S. K. Koenig, et al. “Temporal Dynamics of the Human Vaginal Microbiota.” Science Translational Medicine 4, no. 132 (May 2, 2012). https://doi.org/10.1126/scitranslmed.3003605.
from the subject "5"